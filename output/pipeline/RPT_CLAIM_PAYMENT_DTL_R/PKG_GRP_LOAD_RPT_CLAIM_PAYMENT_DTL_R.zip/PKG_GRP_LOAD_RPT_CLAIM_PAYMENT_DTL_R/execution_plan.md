
# Execution Plan — PKG_GRP_LOAD_RPT_CLAIM_PAYMENT_DTL_R

**Generated:** 2026-08-06
**Status:** ✅ Completed — 2026-08-06
**RPT:** RPT_CLAIM_PAYMENT_DTL_R | **Rank:** 3 | **Tier:** 1 | **Scope:** GLOBAL
**Planner analysis:** 1 rec, 3 steps, 4 cross-package impacts (1 with a cascade)

---

## Recommendations in Scope

| Rec ID | Phase | Category | Risk | Review Status | Validator Comments |
|--------|-------|----------|------|----------------|---------------------|
| M-0004 | 0 — Decisions & Constraints | E. MV Shared Across RPTs (No Blind Elimination) | MEDIUM | ✅ Consider | ⚠️ "A detailed impact analysis is required to validate that there are no direct dependencies on the MV before proceeding with its removal." |

Note: the registry's `applicable_agents` field for this package lists only `optimizer` + `standardizer`.
Per Planner rules, category **E** recs are still routed through the **Merger** first (handled as an
"E inline" action), then Optimizer runs its own discovery pass, then Standardizer — same 3-stage
pipeline as every other package.

---

## Step 0 — Pending Cross-Impacts

`pending_cross_impacts` is empty for this package. **NONE.**

---

## Compound Pattern Detection

Only one recommendation exists in this package — no GTT+Cursor or naming-dependency compounds apply.

---

## Global Impact — FCT_GRP_POLICY_R_MV_SSL (appears in 6 RPTs)

**Home RPT:** none — this MV is refreshed as a standalone Tidal job (`EDP_GRP_EDW_MV_REFRESH_FCT_GRP_POLICY_R_MV_SSL-6`), not owned by a single package's `rpt` field.
**Also used by:** RPT_CLAIM_DTL_R, RPT_CLAIM_SUM_R, RPT_DICS_CLAIMS_DETAIL_OAC_R, RPT_FCT_RPT_CLAIM_SUMMARY_R, RPT_FCT_RPT_CLAIM_SUMMARY_R_HIST (plus this RPT)

**MV definition (verified from source):**
```sql
CREATE MATERIALIZED VIEW ATOMIC.FCT_GRP_POLICY_R_MV_SSL (N_CUST_PARTY_SK_R, N_POLICY_SK_R, N_VERSION_NUMBER_R)
...
AS SELECT max(n_cust_party_sk_r) n_cust_party_sk_r, n_policy_sk_r, n_version_number_r
   FROM fct_grp_policy_r
   GROUP BY n_policy_sk_r, n_version_number_r
```
This is a simple aggregate over `FCT_GRP_POLICY_R` — confirms the validator's note that it "contains
only simple logic" and is safe to inline as a CTE. The exact CTE text is already present as a
**commented-out block** inside [PKG_GRP_LOAD_RPT_CLAIM_DTL_R.sql](../../../../../SQLObjectParser/All_Metadata/PKG_GRP_LOAD_RPT_CLAIM_DTL_R.sql#L1636-L1642), left by a previous developer.

| Script | Source | Reference type (code-verified) | Change required |
|--------|--------|--------------------------------|------------------|
| PKG_GRP_LOAD_RPT_CLAIM_PAYMENT_DTL_R *(this package)* | home | Subquery in LEFT JOIN — [00_source.sql](00_source.sql#L334-L337) | Replace subquery with inlined CTE |
| PKG_GRP_LOAD_RPT_CLAIM_SUM_R | sql_objects_called (lineage) | Direct table JOIN — [PKG_GRP_LOAD_RPT_CLAIM_SUM_R.sql](../../../../../SQLObjectParser/All_Metadata/PKG_GRP_LOAD_RPT_CLAIM_SUM_R.sql#L242) | Replace JOIN target with inlined CTE |
| DIM_GRP_CLAIM_POLICY_DETAIL_EMP_MV_SSL | gap_consumers ⚠️ / cascade 🔗 (M-0105) | Direct FROM — [DIM_GRP_CLAIM_POLICY_DETAIL_EMP_MV_SSL.sql](../../../../../SQLObjectParser/All_Metadata/DIM_GRP_CLAIM_POLICY_DETAIL_EMP_MV_SSL.sql#L37-L38) | This MV is itself scheduled for elimination under M-0105 — see cascade note below |
| PKG_GRP_LOAD_RPT_CLAIM_DTL_R | gap_consumers ⚠️ | Consumer subquery — [line 1643](../../../../../SQLObjectParser/All_Metadata/PKG_GRP_LOAD_RPT_CLAIM_DTL_R.sql#L1643) **AND** MV-refresh owner — `dbms_mview.refresh('FCT_GRP_POLICY_R_MV_SSL', ...)` at [lines 1937-1939](../../../../../SQLObjectParser/All_Metadata/PKG_GRP_LOAD_RPT_CLAIM_DTL_R.sql#L1937-L1939) | Replace consumer join with CTE; **also** remove the embedded refresh call at decommission time (not just the Tidal job) |
| PKG_GRP_LOAD_RPT_CLAIM_DTL_R_INC | gap_consumers ⚠️ | Consumer — [lines 1935](../../../../../SQLObjectParser/All_Metadata/PKG_GRP_LOAD_RPT_CLAIM_DTL_R_INC.sql#L1935), [3967](../../../../../SQLObjectParser/All_Metadata/PKG_GRP_LOAD_RPT_CLAIM_DTL_R_INC.sql#L3967) **AND** MV-refresh owner — [lines 4261-4263](../../../../../SQLObjectParser/All_Metadata/PKG_GRP_LOAD_RPT_CLAIM_DTL_R_INC.sql#L4261-L4263) | Same as above |

**⚠️ New finding (not in original recommendation text):** the MV refresh is embedded as a
`dbms_mview.refresh()` call inside **both** `PKG_GRP_LOAD_RPT_CLAIM_DTL_R` and
`PKG_GRP_LOAD_RPT_CLAIM_DTL_R_INC` — not only driven by the Tidal job. Decommission (Step 5 of the
recommendation) must remove these embedded calls too, or the refresh will error on a dropped table.

### 🔗 Cascade Detected — DIM_GRP_CLAIM_POLICY_DETAIL_EMP_MV_SSL

| Consumer | Also targets rec | Cascade note |
|----------|------------------|--------------|
| DIM_GRP_CLAIM_POLICY_DETAIL_EMP_MV_SSL | M-0105 (home RPT: RPT_CLAIM_NOTE_R, risk HIGH) | This consumer is itself a global E. target — sequence elimination carefully |

**Sequencing rule:** M-0105 plans to inline `DIM_GRP_CLAIM_POLICY_DETAIL_EMP_MV_SSL` directly into its
sole consumer (`FCT_GRP_CLAIM_NOTE_R_DRQ_MV_SSL_INC`). Since that MV's own definition still reads
`FCT_GRP_POLICY_R_MV_SSL`, whichever change lands second must account for the other:
- If M-0105 is planned/executed first, its inlined replacement query should reference the **new**
  `FCT_GRP_POLICY_R_MV_SSL`-CTE logic (i.e., `FCT_GRP_POLICY_R` directly), not the MV.
- If this package's change lands first, `DIM_GRP_CLAIM_POLICY_DETAIL_EMP_MV_SSL` keeps working
  unchanged (MV stays until M-0105 is planned) — no immediate action required here, but do not
  drop `FCT_GRP_POLICY_R_MV_SSL` until M-0105 has also migrated off it.
- Coordinate with `@PL/SQL Planner PKG_GRP_LOAD_RPT_CLAIM_NOTE_R` (or the M-0105 owning package)
  before either package proceeds to Step 5 (decommission).

---

## Data Profile — PKG_GRP_LOAD_RPT_CLAIM_PAYMENT_DTL_R

| Table | Role | Rows | Size (MB) | Indexes | Has Unique? |
|-------|------|-----:|----------:|--------:|:-----------:|
| FCT_GRP_POLICY_R_MV_SSL | rec target (MV to eliminate) | 1,714,693 | 108.0 | 2 | Yes |
| FCT_GRP_POLICY_R (MV's source table) | SOURCE | 1,766,148 | 259,541.75 | 8 | Yes |
| RPT_CLAIM_PAYMENT_DTL_R | TARGET (pkg load) | 1,143,436,954 | 18,826,575.25 | 12 | No |
| RPT_CLAIM_PAYMENT_DTL_R_EXG | TARGET | 0 | 739,536.25 | 0 | No |
| RPT_CLAIM_SUM_R | TARGET | n/a (no Table_Info metadata) | n/a | 0 | No |
| RPT_CLAIM_SUM_R_EXG | TARGET | 2,339,534 | 32,548.5 | 0 | No |

**Risk annotations triggered:**
- ⚠️ **Large table** — `RPT_CLAIM_PAYMENT_DTL_R` has 1.14B rows. Merger should ensure any touched
  DML against this target uses `/*+ APPEND */` / parallel hints where applicable.
- ⚠️ **Large table (>10 GB)** — `RPT_CLAIM_PAYMENT_DTL_R` is ~18.4 TB. Validate UNDO/TEMP headroom
  before running full pipeline cycles for parity validation.
- `RPT_CLAIM_SUM_R` / `RPT_CLAIM_SUM_R_EXG` have `index_count = 0` in metadata, but `RPT_CLAIM_SUM_R`
  has no Table_Info entry at all (`meta_coverage: 18/22`) — treat as **unverified**, not necessarily
  index-free. Confirm actual index state with DBA before assuming none exist.

**Validation checklist additions:**
- [ ] Baseline row-count / key-metric snapshot for all 4 downstream consumers before any CTE swap.
- [ ] Confirm UNDO/TEMP tablespace headroom before running 3+ full pipeline cycles on `RPT_CLAIM_PAYMENT_DTL_R`.
- [ ] Verify no other undiscovered `dbms_mview.refresh('FCT_GRP_POLICY_R_MV_SSL', ...)` callers exist beyond the two found here (grep across `All_Metadata/` before dropping the MV).

---

## Step 1 — Stage 1: Merger (all registry recs) `[Phases 1–4 combined]`

- **Rec(s):** M-0004
- **Agent:** PL/SQL Merger
- **Risk:** MEDIUM
- **Input file:** `00_source.sql`
- **Actions:** Replace the subquery at lines 334-337 (`SELECT N_CUST_PARTY_SK_R, N_POLICY_SK_R, N_VERSION_NUMBER_R FROM ATOMIC.FCT_GRP_POLICY_R_MV_SSL`) with an inlined CTE reproducing the MV's own definition (`MAX(n_cust_party_sk_r) ... GROUP BY n_policy_sk_r, n_version_number_r FROM fct_grp_policy_r`). Local change only — does **not** drop the MV or touch the Tidal refresh job (that requires the full global migration across all 4 consumers first).
- **DBA actions (deferred until all consumers migrate):**
  - Remove Tidal job `EDP_GRP_EDW_MV_REFRESH_FCT_GRP_POLICY_R_MV_SSL-6`.
  - Remove embedded `dbms_mview.refresh('FCT_GRP_POLICY_R_MV_SSL', ...)` calls in `PKG_GRP_LOAD_RPT_CLAIM_DTL_R` and `PKG_GRP_LOAD_RPT_CLAIM_DTL_R_INC`.
  - Drop table `FCT_GRP_POLICY_R_MV_SSL` after 3+ pipeline cycles pass parity across ALL 4 consumers (this package, PKG_GRP_LOAD_RPT_CLAIM_SUM_R, PKG_GRP_LOAD_RPT_CLAIM_DTL_R, PKG_GRP_LOAD_RPT_CLAIM_DTL_R_INC), and after M-0105 cascade is resolved.
- **→ Produces:** `01_merged.sql`

## Step 2 — Stage 2: Optimizer (discovery scan) `[Mode A — post-merger]`

- **Agent:** PL/SQL Optimizer
- **Input:** `01_merged.sql`
- **Action:** Scan for new optimization opportunities not already covered by M-0004.
- **→ Produces:** `02_optimizer_report.md` + `02_optimized.sql` (if changes approved)

## Step 3 — Stage 3: Standardizer `[always last]`

- **Agent:** PL/SQL Standardize
- **→ Produces:** `03_standardized.sql`

---

## Cross-Package Impact Plan

For each of the 4 consumers of `FCT_GRP_POLICY_R_MV_SSL` identified above, choose how to proceed:

- **Option A — Apply now:** immediately patch all 4 consumer files with the same CTE-inline change, write `00_cross_impact_M0004.sql` in each package's pipeline folder, log to their `decisions.md`.
- **Option B — Register as pending:** add `M-0004` to each consumer's `pending_cross_impacts` in the registry; the change is applied automatically the next time each package is run through the Planner (Step 0).
- **Option C — Document only:** record the impact in this plan and each consumer's `decisions.md` without touching code; developer applies manually later.

Given the MV cannot be dropped until **all** consumers migrate (global scope, no blind elimination),
Option B (register as pending) is recommended so each consumer package gets the change automatically
queued the next time it's planned, without forcing an out-of-band multi-package edit right now.

**Decision: Option B selected (2026-08-06).** Status per consumer:

| Consumer | `pending_cross_impacts` in registry | `decisions.md` |
|----------|--------------------------------------|----------------|
| PKG_GRP_LOAD_RPT_CLAIM_SUM_R | ✅ registered | ✅ logged |
| PKG_GRP_LOAD_RPT_CLAIM_DTL_R | ⚠️ blocked — see note below | ✅ logged |
| PKG_GRP_LOAD_RPT_CLAIM_DTL_R_INC | ⚠️ blocked — see note below | ✅ logged |
| DIM_GRP_CLAIM_POLICY_DETAIL_EMP_MV_SSL | n/a (no code change needed yet — cascade note only) | ✅ logged |

⚠️ **Registry limitation:** `PKG_GRP_LOAD_RPT_CLAIM_DTL_R` and `PKG_GRP_LOAD_RPT_CLAIM_DTL_R_INC` both
carry the M-0091/M-0092/M-0101/M-0102 recommendation blocks byte-identical to `PKG_GRP_LOAD_RPT_CLAIMANT_DTL_R_INC`'s
copies, making a safe unique text-match edit to `pipeline_registry.json` impractical by hand for these
two packages. Their `decisions.md` files carry the full pending cross-impact detail as the authoritative
record until a JSON-aware script applies the registry update.

---

## DBA Actions Summary

| Action | When |
|--------|------|
| Baseline row-count/key-metric snapshot for all 4 consumers | Before Step 1 of any consumer's migration |
| Remove embedded `dbms_mview.refresh('FCT_GRP_POLICY_R_MV_SSL', ...)` in `PKG_GRP_LOAD_RPT_CLAIM_DTL_R` / `_INC` | At decommission, after all consumers pass parity |
| Remove Tidal job `EDP_GRP_EDW_MV_REFRESH_FCT_GRP_POLICY_R_MV_SSL-6` + scheduler dependency edges | At decommission |
| Drop table `FCT_GRP_POLICY_R_MV_SSL` | At decommission, after M-0105 cascade also resolved |

---

## Summary Metrics

| Metric | Value |
|--------|-------|
| Recommendations | 1 (M-0004) |
| Steps | 3 (Merger → Optimizer → Standardizer) |
| Cross-package impacts | 4 (PKG_GRP_LOAD_RPT_CLAIM_SUM_R, DIM_GRP_CLAIM_POLICY_DETAIL_EMP_MV_SSL, PKG_GRP_LOAD_RPT_CLAIM_DTL_R, PKG_GRP_LOAD_RPT_CLAIM_DTL_R_INC) |
| Cascades | 1 (M-0105 via DIM_GRP_CLAIM_POLICY_DETAIL_EMP_MV_SSL) |
| Hop savings (this package alone) | 0 (full hop elimination only realized once ALL 4 consumers + Tidal job migrate) |

---

## Approval

```
approve            — approve full plan and begin execution
revise step N       — request change to a specific step
cross-impacts A     — apply cross-impacts to all affected packages now
cross-impacts B     — register as pending cross-impacts (recommended)
cross-impacts C     — document only
abort               — cancel, no changes made
```

Plan approved and fully executed on 2026-08-06.

---

## Stage Log

| Stage | Date | Decision | Notes |
|-------|------|----------|-------|
| Plan generated | 2026-08-06 | — | Awaiting developer approval |
| Cross-impacts | 2026-08-06 | Option B selected | Registered pending in PKG_GRP_LOAD_RPT_CLAIM_SUM_R; logged (registry-blocked) in PKG_GRP_LOAD_RPT_CLAIM_DTL_R / _INC; informational note added to DIM_GRP_CLAIM_POLICY_DETAIL_EMP_MV_SSL |
| Plan approved | 2026-08-06 | approve | Beginning Step 1 (Merger) |
| Step 1 — Merger | 2026-08-06 | ✅ Applied | M-0004 inlined at 00_source.sql lines 334-337 → 01_merged.sql; MV/refresh job untouched (deferred) |
| Step 2 — Optimizer | 2026-08-06 | ✅ Applied OPP-2, OPP-3 | OPP-1 deferred (business/BI decision needed), OPP-4 DBA-only (no code change) → 02_optimized.sql |
| Step 3 — Standardizer | 2026-08-06 | ✅ Applied 1, 3, 5 | AS keyword aliases, SQLCODE capture, stale comment removed → 03_standardized.sql; #2/#4/#6/#7/#8 skipped (see decisions.md) |
| Execution complete | 2026-08-06 | ✅ Completed | All 3 stages done: 01_merged.sql → 02_optimized.sql → 03_standardized.sql |
